# Project Memory: demo-project

## Project Summary
Demo project used as a template for task-based multi-agent execution.

## Local Conventions
- migration must be idempotent
- tests must exist for critical command paths
- docs changes should include usage and rollback notes where applicable

## Important Repeated Facts
- migration must be idempotent
- migration must be idempotent

## Related Files
- /repo/src/
- /repo/tests/
- /repo/tasks/tsecs/
