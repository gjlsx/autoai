# Tasklist

> Scheduler creates and maintains the structure of this file.
> Executor may update only: Owner, Status, Claim, Finish, Report, Git, Review, Score.

| TaskID | Project | Title | Description | Type | Priority | Role | Owner | Depends | Status | Claim | Finish | Report | Git | Review | Score |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| t0316.p10 | demo-project | Add schema sync command | Add idempotent schema sync entrypoint and tests | feature | P0 | codex |  |  | todo |  |  |  |  |  |  |
| t0316.p11 | demo-project | Write migration docs | Document migration usage and rollback notes | docs | P1 | claude |  | t0316.p10 | todo |  |  |  |  |  |  |

## Field Rules
- `TaskID`: global unique id, format `tYYMMDD.pXXX`
- `Project`: current project folder name under `memorys/projects/`
- `Role`: target executor role
- `Depends`: comma-separated task IDs or empty
- `Claim` example:
  - `startat:260316185749 codex tasks/codex/t0316.p10.md`
- `Finish` example:
  - `finishat:260316192301`
- `Review` examples:
  - `pass:no-refactor-needed`
  - `pass:minor-refactor-done`
  - `partial:needs-followup`
- `Score` example:
  - `91/100`

## Status Meanings
- `todo`: not claimed
- `doing`: claimed and being worked on
- `blocked`: cannot proceed because of dependency or environment issue
- `partial`: partially completed with next steps documented
- `pending`: paused for external reasons
- `done`: completed with tests passed and self-review finished
- `cancelled`: no longer needed
