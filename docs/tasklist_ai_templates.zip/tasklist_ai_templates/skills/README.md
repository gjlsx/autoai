# Skills Directory

This directory stores passive, reusable internal skill documents.

Suggested files:
- `task-claim.md`
- `lock-recovery.md`
- `test-first.md`
- `self-review-checklist.md`

Current rule:
- skills are documentation first
- do not treat skills as executable automation unless explicitly upgraded later
