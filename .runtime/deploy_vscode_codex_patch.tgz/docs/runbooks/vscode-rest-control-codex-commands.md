# VSCode Codex + REST Control Commands

## Endpoint
- Default: `http://127.0.0.1:49818`
- Request format:

```json
{
  "command": "<command-id>",
  "args": []
}
```

## Core Command IDs (verified)
- `chatgpt.openSidebar`
- `chatgpt.sidebarView.focus`
- `workbench.action.chat.focusInput`
- `type` (`args=[{"text":"..."}]`)
- `workbench.action.chat.submit`
- `workbench.action.chat.copyAll`
- `chatgpt.newChat`
- `custom.getCommands`
- `custom.eval`

## Fixed Pipeline Used By `vscode_codex_worker.py`
1. `chatgpt.newChat` (only when `sessionid` changed)
2. `workbench.action.chat.copyAll` + `custom.eval("vscode.env.clipboard.readText()")` (baseline)
3. `chatgpt.openSidebar`
4. `chatgpt.sidebarView.focus`
5. `workbench.action.chat.focusInput`
6. `type` (`{"text":"<message>"}`)
7. `workbench.action.chat.submit`
8. polling loop:
   - `workbench.action.chat.copyAll`
   - `custom.eval("vscode.env.clipboard.readText()")`
   - delta extract and emit feedback

## Quick Checks

### 1) List commands
```powershell
@'
import json, urllib.request
req = urllib.request.Request(
    "http://127.0.0.1:49818",
    data=json.dumps({"command":"custom.getCommands"}).encode("utf-8"),
    headers={"Content-Type":"application/json"},
    method="POST",
)
print(urllib.request.urlopen(req, timeout=5).read().decode("utf-8")[:500])
'@ | python -
```

### 2) Focus Codex sidebar
```powershell
@'
import json, urllib.request
payload = {"command":"chatgpt.sidebarView.focus"}
req = urllib.request.Request(
    "http://127.0.0.1:49818",
    data=json.dumps(payload).encode("utf-8"),
    headers={"Content-Type":"application/json"},
    method="POST",
)
print(urllib.request.urlopen(req, timeout=5).read().decode("utf-8"))
'@ | python -
```

### 3) Read clipboard via `custom.eval`
```powershell
@'
import json, urllib.request
payload = {"command":"custom.eval","args":["vscode.env.clipboard.readText()"]}
req = urllib.request.Request(
    "http://127.0.0.1:49818",
    data=json.dumps(payload).encode("utf-8"),
    headers={"Content-Type":"application/json"},
    method="POST",
)
print(urllib.request.urlopen(req, timeout=5).read().decode("utf-8"))
'@ | python -
```

## Failure Policy (implemented)
- No fallback to PTY/CLI for `codex`.
- Each critical step retries `3` times.
- After `3` failures:
  - write `ai_feedback` `channel=system` with `task_id/sessionid/step/retries/last_error`
  - update `ai_tasks.status='failed'` and `last_error`
  - cloud outbound loop sends Telegram alert to `source_chat_id` first.

