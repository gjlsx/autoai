# AutoAI README

1. 先讀需求文檔  
- `docs/需求説明.md`

2. 私密配置  
- Redis / MySQL / Telegram token 等放在根目錄 `.env`

3. 連接遠端服務器  
- 參考：`docs/遠端服務器標準連接流程.md`
- 標準命令：

```powershell
ssh -i "D:\temp\aws\keygool_anpingli" -p 22 lianping1230@34.101.230.107
```
 若 SSH 偶發卡住，按一次 Enter。

4. 雲端 FastAPI 管理器入口  
- `cloud_orchestrator/main.py`

5. 雲端部署與驗證文檔  
- `docs/plans/2026-03-02-fastapi-cloud-orchestrator-implementation-plan.md`
- `docs/runbooks/fastapi-orchestrator-e2e.md`

6. 本地一鍵啟停  
- 啟動（預設 VSCode Codex Worker）：`python .\scripts\one_click.py start`
- 啟動（含 Claude）：`python .\scripts\one_click.py start --start-claude`
- 啟動（含 Claude + Gemini）：`python .\scripts\one_click.py start --start-claude --start-gemini`
- 啟動（啟用 Codex Agent Worker）：`python .\scripts\one_click.py start --start-codex-agent`
- 啟動（舊 window_bridge 模式）：`python .\scripts\one_click.py start --bridge-mode window`
- 狀態：`python .\scripts\one_click.py status`
- 停止：`python .\scripts\one_click.py stop`
- 回寫：`python .\scripts\one_click.py feedback --task-id <id> --message "done" --source-ai codex`
- 演練（不實際啟動）：`python .\scripts\one_click.py start --dry-run`

`matrix_ui.py` 頂部也已接入一鍵 `start/stop/status` 按鈕，按鈕會直接調用 `scripts/one_click.py`。

7. 本地一鍵操作手冊  
- `docs/runbooks/local-one-click-operation.md`

8. Feedback 走通測試（雲 MySQL + Telegram）
- `python .\scripts\feedback_flow_test.py --inject --chat-id 1261596828 --payload "feedback smoke from script"`
- `python .\scripts\feedback_loop_e2e_test.py --chat-id 1261596828 --timeout-sec 40`

9. PTY Worker（Windows）
- 探測三方案並選型：`python .\scripts\run_pty_backend_probe.py --output-json .\.runtime\pty_backend_report.json`
- 任務說明與 Task1-4 狀態：`docs/tasktodo0302.md`
- Worker 入口：`pty_worker.py`
- VSCode Codex Worker 入口：`vscode_codex_worker.py`
- VSCode/REST 命令字典：`docs/runbooks/vscode-rest-control-codex-commands.md`
- 全鏈路煙霧測試：`python .\scripts\e2e_pty_pipeline_smoke.py --timeout-sec 120 --port 9913`
- Codex Agent（task0203_b）煙霧測試：`python .\scripts\e2e_codex_agent_pipeline_smoke.py --timeout-sec 120 --port 9923`
- 集成記錄（問題與解法）：`docs/runbooks/pty-worker-integration.md`
